package day3;

public class Task3 {
    public static void main(String[] args) {

    }
}
