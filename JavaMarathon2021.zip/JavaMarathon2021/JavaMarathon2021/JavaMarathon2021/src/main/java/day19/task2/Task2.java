package day19.task2;

/**
 * @author Neil Alishev
 */
public class Task2 {
    public static void main(String[] args) {

    }
}

