package day19;

/**
 * @author Neil Alishev
 */
public class Task1 {
    public static void main(String[] args) {

    }
}
