package day1;

public class Task3 {
    public static void main(String[] args) {
        int val=0;
        while (val<10){
            System.out.println("JAVA");
            val=val+1;
        }
    }
}