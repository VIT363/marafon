package day1;

public class Task1 {
    public static void main(String[] args) {
        int value = 0;
        while (value < 10) {
            System.out.print("JAVA"+" ");
            value = value + 1;
        }
    }
}
