package day6;

public class Task3 {
    public static void main(String[] args) {

    }
}
