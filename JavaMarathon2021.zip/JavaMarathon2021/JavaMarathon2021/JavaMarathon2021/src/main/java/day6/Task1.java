package day6;

public class Task1 {
    public static void main(String[] args) {

    }
}
