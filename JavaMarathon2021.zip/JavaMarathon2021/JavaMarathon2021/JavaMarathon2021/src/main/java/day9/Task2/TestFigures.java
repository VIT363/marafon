package day9.Task2;

public class TestFigures {
    public static void main(String[] args) {

    }
}
