package day17;

public class Task1 {
    public static void main(String[] args) {

    }
}