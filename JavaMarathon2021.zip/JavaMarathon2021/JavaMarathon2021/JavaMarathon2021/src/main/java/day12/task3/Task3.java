package day12.task3;

public class Task3 {
    public static void main(String[] args) {

    }
}
