package day12.task5;

public class Task5 {
    public static void main(String[] args) {

    }
}
