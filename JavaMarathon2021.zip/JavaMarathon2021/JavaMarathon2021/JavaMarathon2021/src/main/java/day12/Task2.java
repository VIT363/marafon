package day12;

public class Task2 {
    public static void main(String[] args) {

    }
}
