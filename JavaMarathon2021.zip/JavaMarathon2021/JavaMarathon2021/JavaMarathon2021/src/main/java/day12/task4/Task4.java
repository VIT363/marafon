package day12.task4;

public class Task4 {
    public static void main(String[] args) {

    }
}
