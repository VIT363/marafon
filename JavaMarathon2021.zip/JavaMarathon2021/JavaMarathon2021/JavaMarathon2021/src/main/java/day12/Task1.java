package day12;

public class Task1 {
    public static void main(String[] args) {

    }
}
