package day18;

public class Task3 {
    public static void main(String[] args) {

    }
}