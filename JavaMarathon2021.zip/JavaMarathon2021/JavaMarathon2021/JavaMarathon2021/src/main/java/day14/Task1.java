package day14;

public class Task1 {
    public static void main(String[] args) {

    }
}
