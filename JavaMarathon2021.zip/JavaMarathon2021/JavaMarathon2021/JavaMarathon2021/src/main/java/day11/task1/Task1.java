package day11.task1;

public class Task1 {
    public static void main(String[] args) {

    }
}
